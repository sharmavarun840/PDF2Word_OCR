from pdf2docx import Converter
import pytesseract
from pdf2image import convert_from_path

# Specify the path to the Poppler bin directory
poppler_path = r'C:\Users\Admin\Desktop\TOOL\Release-24.02.0-0\poppler-24.02.0\Library\bin'

# Specify the path to the Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Path to the PDF file (update this path as needed)
pdf_path = r'C:\Users\Admin\Desktop\TOOL\format1.pdf'
docx_path = r'C:\Users\Admin\Desktop\TOOL\output.docx'

# Function to convert PDF to DOCX
def convert_pdf_to_docx(pdf_path, docx_path):
    cv = Converter(pdf_path)
    cv.convert(docx_path, start=0, end=None)
    cv.close()
    print("Conversion complete. Saved to " + docx_path)

# Function to extract text using OCR
def extract_text_with_ocr(pdf_path):
    images = convert_from_path(pdf_path, poppler_path=poppler_path)
    text = ''
    for image in images:
        text += pytesseract.image_to_string(image)
    return text

# Main function
def main():
    # Convert PDF to DOCX
    convert_pdf_to_docx(pdf_path, docx_path)

    # Extract text using OCR
    ocr_text = extract_text_with_ocr(pdf_path)
    with open(r'C:\Users\Admin\Desktop\TOOL\ocr_extracted_text.txt', 'w', encoding='utf-8') as f:
        f.write(ocr_text)
    print("OCR text extraction complete. Saved to ocr_extracted_text.txt")

if __name__ == "__main__":
    main()