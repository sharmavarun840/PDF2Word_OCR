from pdf2docx import Converter

# Path to the PDF file
pdf_path = r"C:\Users\Admin\Desktop\TOOL\format1.pdf"
# Path to the output DOCX file
docx_path = r"C:\Users\Admin\Desktop\TOOL\format1_converted.docx"

# Create a Converter object
cv = Converter(pdf_path)
# Convert the PDF to DOCX
cv.convert(docx_path, start=0, end=None)
# Close the Converter object
cv.close()

print("Conversion complete. Saved to " + docx_path)